//  描述：包含程序所依赖的头文件和命名空间
//-------------------------------------------------------------------------------------------------------
//#include "lib_gaussianfilter.cpp"
#include "lib_fourier.cpp"
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <iostream>
using namespace std;
using namespace cv;
// 【全局变量声明部分】
//  描述：包含程序所依赖的头文件和命名空间
//-------------------------------------------------------------------------------------------------------
#define GAUSS_2D 1 // 二维高斯滤波
#define GAUSS_1D 0 // 一维高斯滤波
main()
{
    Mat src,dst,dstP;
    // 载入原图
    src = imread("../img/input.png",IMREAD_COLOR);
    cvtColor(src,src,CV_BGR2GRAY); // 准换为灰度图
    if(src.empty())
    {
        cout << "FAIL TO LOAD IAMGE" << endl;
        return -1;
    }
    else
    {
        cout << "SUCCESS TO LOAD IMAGE" << endl;
        imshow("input image",src);    
    }

    //【<1>高斯滤波】
    // 1. 设计2D高斯模板（给定方差生成滤波核）
    // 2. 图像的高斯滤波
    // 3. 高斯滤波中不同边界处理方法
    cout << "TASK 1: 高斯滤波模板（2D）实验" << endl;
    GaussianFilter(src,dst,(int)5,(double)2);
    imshow("TASK 1: Gaussian Filter 2D Output",dst);
    imwrite("../img/gaussian_filter_2d_output.png",dst);
    //【<2>高斯与高斯核的卷积实验】
    // 1. 两个相同方差的一维高斯核卷积生成二维高斯核，利用一维行列高斯对图像进行滤波
    // 2. 不同方差高斯核之差对图像进行滤波
    cout << "TASK 2: 高斯滤波模板（1D）实验" << endl;
    GaussianFilter(src,dst,(int)5,(double)1,(double)1,GAUSS_1D);
    imwrite("../img/gaussian_filter_1d_equal_output.png",dst);
    imshow("TASK 2.1: Gaussian Filter 1D sigma_equal Output",dst);
    GaussianFilter(src,dst,(int)5,(double)1,(double)3,GAUSS_1D);
    imwrite("../img/gaussian_filter_1d_unequal_output.png",dst);
    imshow("TASK 2.2: Gaussian Filter 1D sigma_unequal Output",dst);
    // 【<3>锐化滤波器设计】
    // 1. 利用两个高斯核设计图像锐化滤滤波器核
    cout << "TASK 3: 图像锐化滤波器实验" << endl;
    GaussianShapenFilter(src,dst,10);
    imshow("TAKS 3: Image Sharpenning Output",dst);
    imwrite("../img/sharpen_output.png",dst);
    // 【<4>双边滤波器】
    // 1. 图像的双边滤波实验
    cout << "TASK 4: 双边滤波实验" << endl;
    bilateralFilter(src,dst,20,50,30);
    imwrite("../img/bilateral_output.png",dst);
    imshow("TASK 4: Bilateral Output",dst);
    // 【<5>傅里叶变换】
    // 1. 图像的傅里叶变换，显示幅度谱和相位谱
    // 2. 利用高斯滤波器对图像的频率域滤波
    cout << "TASK 5: Fourier变换实验" << endl;
    Fourier(src,dst,dstP);
    imwrite("../img/fourier_output_I.png",dst);
    imshow("TAKS 5: Fourier Output I",dst);
    imwrite("../img/fourier_output_P.png",dstP);
    imshow("TAKS 5: Fourier Output P",dstP);
    FourierFilterHighPass(src,dst,dstP);
    imwrite("../img/fourier_output_highpass_P_raw.png",dst);
    imshow("TAKS 5: Fourier Output P highpass raw",dst);
    imwrite("../img/fourier_output_highpass_P_fourier.png",dstP);
    imshow("TAKS 5: Fourier Output P highpass fourier",dstP);
    FourierFilterLowPass(src,dst,dstP);
    imwrite("../img/fourier_output_lowpass_P_raw.png",dst);
    imshow("TAKS 5: Fourier Output P lowpass raw",dst);
    imwrite("../img/fourier_output_lowpass_P_fourier.png",dstP);
    imshow("TAKS 5: Fourier Output P lowpass fourier",dstP);
    waitKey(0);
    return 0;
}