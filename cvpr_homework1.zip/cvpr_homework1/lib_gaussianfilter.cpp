#include <iostream>
#include <chrono>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

using namespace std;
using namespace cv;

void GaussianFilter(const cv::Mat &src, cv::Mat &dst, int ksize=3, double sigma=1, double sigma_1d=0, int gaussian_flag=1)
{
    CV_Assert(src.channels() || src.channels() == 3); // 只处理单通道或者三通道图像
    const static double pi = 3.1415926;
    // 根据窗口大小和sigma生成高斯滤波器模板
    // 申请一个二维数组，存放生成的高斯模板矩阵
    double **templateMatrix = new double*[ksize];
    // 申请两个一维数组，存放一维高斯卷积核
    double *matrix1 = new double [ksize];
    double *matrix2 = new double [ksize];
    double sum = 0;
    for (int i = 0; i < ksize; i++)
        templateMatrix[i] = new double[ksize];
    if(gaussian_flag)
    {
        cout << "2D 高斯模板生成中..." << endl;
        cout << "模板大小为: " << ksize << endl << "方差为: " << sigma << endl; 
        int origin = ksize / 2; // 以模板的中心为原点
        double x2, y2;
        for (int i = 0; i < ksize; i++)
        {
            x2 = pow(i - origin, 2);
            for (int j = 0; j < ksize; j++)
            {
                y2 = pow(j - origin, 2);
                // 高斯函数前的常数可以不用计算，会在归一化的过程中给消去
                double g = exp(-(x2 + y2) / (2 * sigma * sigma));
                sum += g;
                templateMatrix[i][j] = g;
            }
        }
        cout << "2D 高斯模板:" << endl;
    }
    else
    {
        cout << "1D 高斯模板生成中..." << endl;
        cout << "模板大小为: " << ksize << endl;
        cout << "方差1为: " << sigma << endl;
        cout << "方差2为: " << sigma_1d << endl;
        double x2;
        int origin = ksize/2;   // 以模板中心为原点
        for(int i=0;i<ksize;i++)
        {
            x2 = pow(i-origin,2);
            matrix1[i] = exp(-x2 / (2 * sigma * sigma));
            matrix2[i] = exp(-x2 / (2 * sigma_1d * sigma_1d));
        }
        // 输出生成的一维高斯模板
        cout << "1D 高斯模板:" << endl;
        for(int i=0;i<ksize;i++)
        {
            cout << matrix1[i] << ' ';
        }
        cout << endl << "1D 高斯模板2:" << endl;
        for(int i=0;i<ksize;i++)
        {
            cout << matrix2[i] << ' ';
        }
        cout << endl;
        for(int i=0;i<ksize;i++)
        {
            for(int j=0;j<ksize;j++)
            {
                double g = matrix1[i]*matrix2[j];
                sum += g;
                templateMatrix[i][j] = g;
            }
        }
    }
    cout << "高斯模板:" << endl;
    for (int i = 0; i < ksize; i++)
    {
        for (int j = 0; j < ksize; j++)
        {
            templateMatrix[i][j] /= sum;
            cout << templateMatrix[i][j] << " ";
        }
        cout << endl;
    }
    // 将模板应用到图像中
    int border = ksize / 2;
    copyMakeBorder(src, dst, border, border, border, border, BorderTypes::BORDER_REFLECT);
    int channels = dst.channels();
    int rows = dst.rows - border;
    int cols = dst.cols - border;
    for (int i = border; i < rows; i++)
    {
        for (int j = border; j < cols; j++)
        {
            double sum[3] = { 0 };
            for (int a = -border; a <= border; a++)
            {
                for (int b = -border; b <= border; b++)
                {
                    if (channels == 1)
                    {
                        sum[0] += templateMatrix[border + a][border + b] * dst.at<uchar>(i + a, j + b);
                    }
                    else if (channels == 3)
                    {
                        Vec3b rgb = dst.at<Vec3b>(i + a, j + b);
                        auto k = templateMatrix[border + a][border + b];
                        sum[0] += k * rgb[0];
                        sum[1] += k * rgb[1];
                        sum[2] += k * rgb[2];
                    }
                }
            }
            for (int k = 0; k < channels; k++)
            {
                if (sum[k] < 0)
                    sum[k] = 0;
                else if (sum[k] > 255)
                    sum[k] = 255;
            }
            if (channels == 1)
                dst.at<uchar>(i, j) = static_cast<uchar>(sum[0]);
            else if (channels == 3)
            {
                Vec3b rgb = { static_cast<uchar>(sum[0]), static_cast<uchar>(sum[1]), static_cast<uchar>(sum[2]) };
                dst.at<Vec3b>(i, j) = rgb;
            }
        }
    }
    // 释放模板数组
    for (int i = 0; i < ksize; i++)
        delete[] templateMatrix[i];
    delete[] templateMatrix;
}

void GaussianShapenFilter(const cv::Mat &src, cv::Mat &dst, double alpha)
{
    resize(dst,dst,Size(src.cols,src.rows),0,0,CV_INTER_AREA);
    subtract(src,dst,dst);
    scaleAdd(dst,alpha,src,dst);
}