#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Oct 30 13:43:52 2021
calibrateCamera
@author: lyc
"""
'''
pip install opencv-python -i https://pypi.douban.com/simple
pip install numpy -i https://pypi.douban.com/simple
'''
'''
refer: 
    Zhengyou Zhang Calibration:
    https://www.cnblogs.com/wangguchangqing/p/8335131.html
'''
import numpy as np
import cv2
import os
import time
from camera import camera_shoot
import math

class calibrate:
    def __init__(self, height, width):
        self.img_file = 'img\\'
        self.img_list = os.listdir(self.img_file)
        if not self.img_list:  # 如果img文件夹没有图像，则打开摄像头拍摄
            # if img_list is empty
            camera_shoot()
        self.img_list = os.listdir(self.img_file)
        # 标定板大小
        self.height = height
        self.width = width
        # 标定板坐标
        '''
        ---------->y
        |   (0,0,0) ... (0,width,0)
        |   ...
        |   ...
        V   (height,0,0) ... (height,width,0)
        x
        '''
        # 做一些3D点
        self.objp = np.zeros((self.height * self.width, 3), np.float32)
        self.objp[:, :2] = np.mgrid[0:self.height, 0:self.width].T.reshape(-1, 2)
        # print(self.objp)

    def calibrate_auto(self):
        # get points in real world
        corner_point = []
        corner_point_sub_pix = []
        objpoints = []
        for i in range(len(self.img_list)):
            img = cv2.imread(self.img_file + self.img_list[i])
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            flag, corners = cv2.findChessboardCorners(image=gray, patternSize=(self.height, self.width))
            # print(flag) # 是否识别成功
            if flag:
                objpoints.append(self.objp)
                corner_point.append(corners)
                rows, cols = gray.shape
                p0 = corners[0][0]
                p1 = corners[1][0]
                p2 = corners[self.height][0]
                pts1 = np.float32([p0, p1, p2])
                pts2 = np.float32([[0,0], [0,rows/self.height], [cols/self.width,0]])
                M = cv2.getAffineTransform(pts1, pts2)
                dst = cv2.warpAffine(img, M, (cols, rows))
                cv2.imshow('img',dst)
                for pt in corners:
                    point = pt[0]
                    # print(point)
                    circle_gray = gray
                    # 画出角点
                    cv2.circle(circle_gray, center=(int(point[0]), int(point[1])), radius=5, color=(0, 0, 255),
                               thickness=-1)
                # cv2.imshow('corner points', circle_gray)
                # cv2.waitKey(0)
                cv2.imwrite('corner_point\\corner_{}'.format(self.img_list[i]), circle_gray)
                # 为了获得更高的精度，将提取到的像素坐标精确到亚像素
                corners_sub_pix = cv2.cornerSubPix(image=gray, corners=corners, winSize=(self.height, self.width),
                                                   zeroZone=(-1, -1), criteria=(
                        cv2.TERM_CRITERIA_MAX_ITER | cv2.TERM_CRITERIA_EPS, 30, 0.001))
                if corners_sub_pix.any():
                    corner_point_sub_pix.append(corners_sub_pix)
                else:
                    corner_point_sub_pix.append(corners)
        # 标定
        ret, mtx, dist, rvecs, tvecs = cv2.calibrateCamera(objpoints, corner_point_sub_pix, gray.shape, None, None)
        self.calibrate = [ret, mtx, dist, rvecs, tvecs]  # 标定结果
        # print ("ret:", ret)        # ret为bool值
        # print ("mtx:\n", mtx)      # 内参数矩阵
        # print ("dist:\n", dist )   # 畸变系数 distortion cofficients = (k_1,k_2,p_1,p_2,k_3)
        # print ("rvecs:\n", rvecs)  # 旋转向量，外参数
        # print ("tvecs:\n", tvecs ) # 平移向量，外参数

        # 去畸变
        img2 = cv2.imread('test.png')
        h, w = img2.shape[:2]
        newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (w, h), 1, (w, h))  # 自由比例参数
        dst = cv2.undistort(img2, mtx, dist, None, newcameramtx)
        # 根据前面ROI区域裁剪图片
        # x,y,w,h = roi
        # dst = dst[y:y+h, x:x+w]
        cv2.imwrite('calibresult.png', dst)
        cv2.imshow('calibresult.png', dst)
        # 反投影误差
        total_error = 0
        for i in range(len(objpoints)):
            imgpoints2, _ = cv2.projectPoints(objpoints[i], rvecs[i], tvecs[i], mtx, dist)
            error = cv2.norm(corner_point_sub_pix[i], imgpoints2, cv2.NORM_L2) / cv2.norm(imgpoints2, cv2.NORM_L2)
            total_error += error
        # print("total error: ", total_error / len(objpoints))

        return self.calibrate, total_error


if __name__ == '__main__':
    # 使用定焦相机拍摄
    start_time = time.time()
    camera_calibrate = calibrate(height=8, width=6)
    calibrate_data, total_error = camera_calibrate.calibrate_auto()
    print('total error {:%}'.format(total_error))
    # print('[ret, mtx, dist, rvecs, tvecs]\n', calibrate_ans)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print('running time {:.4f}'.format(time.time() - start_time))
