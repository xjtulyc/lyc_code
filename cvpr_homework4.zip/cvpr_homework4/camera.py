#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Oct 30 13:25:15 2021
camera
@author: lyc
"""
import cv2


def camera_shoot():
    cap = cv2.VideoCapture(0)
    # # 设置焦距
    # cap.set(cv2.CV_CAP_PROP_FOCUS, 85)
    # 先设置分辨率，宽：1920 长：1080
    cap.set(3, 1920)
    cap.set(4, 1080)
    # 图像计数 从1开始
    img_count = 1
    print("press 's' to save image\npress 'q' to quit")
    while 1:
        # get a frame
        ret, frame = cap.read()
        if ret:
            # show a frame
            cv2.imshow("capture", frame)
            # 等待按键事件发生 等待1ms
            key = cv2.waitKey(1)
            if key == ord('q'):
                # 如果按键为q 代表quit 退出程序
                print("程序正常退出..")
                break
            elif key == ord('s'):
                # 如果s键按下，则进行图片保存
                # 写入图片 并命名图片为 图片序号.png
                cv2.imwrite("img\\{}.png".format(img_count), frame)
                print("保存图片，名字为  {}.png".format(img_count))
                # 图片编号计数自增1
                img_count += 1

        else:
            print("图像数据获取失败！！")
            break
    cap.release()
    cv2.destroyAllWindows()


if __name__ == '__main__':
    camera_shoot()
