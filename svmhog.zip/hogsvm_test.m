%% Hog特征+SVM分类器 行人识别 测试脚本
% Author: Youcheng Li
% 2021-10-23
clear;
clc;
%% 导入预训练好的SVM分类器
load data.mat
%% 预测并显示预测效果图

t0=clock;
neg_numTest = length(neg_test.Files);
pos_numTest = length(pos_test.Files);
% 真实样本为负例
FP = 0;%预测为正例
TN = 0;%预测为负例
%真实样本为正例
TP = 0;%预测为正例
FN = 0;%预测为负例
score_neg = [];
score_pos = [];
for i = 1:neg_numTest
    testImg = readimage(neg_test,i);
    scaleTestImage = imresize(testImg,imgSize);
    featureTest = extractHOGFeatures(scaleTestImage);
    [predictIndex,score] = predict(classifier,featureTest);
    %     figure;
    %     imshow(testImg);
    %     title(['predictImage: ', char(predictIndex)]);
    %         if(char(predictIndex)=="pos")
    %             FP = FP + 1;
    %         else
    %             TN = TN + 1;
    %         end
    score_neg = [score_neg;score];
    clc;
    disp('running neg ...')
    %         disp(score);
end

for i = 1:pos_numTest
    testImg = readimage(pos_test,i);
    scaleTestImage = imresize(testImg,imgSize);
    featureTest = extractHOGFeatures(scaleTestImage);
    [predictIndex,score] = predict(classifier,featureTest);
    %     figure;
    %     imshow(testImg);
    %     title(['predictImage: ', char(predictIndex)]);
    %         if(char(predictIndex)=="pos")
    %             TP = TP + 1;
    %         else
    %             FN = FN + 1;
    %         end
    score_pos = [score_pos;score];
    clc;
    disp('running pos ...')
    %         disp(score)
end

save score.mat score_neg score_pos