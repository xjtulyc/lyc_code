%% Hog特征+SVM分类器 行人识别
% Author: Youcheng Li
% 2021-10-23
clear;
clc;
% 用Hog特征对图像进行多分类，SVM训练
%% 构建数据集，包括训练集和测试集
train = imageDatastore('D:\xjtu\ai\3\svmhog\datasets\Test', ...
    'IncludeSubfolders',true,...  
    'LabelSource','foldernames'); 
pos_test = imageDatastore('D:\xjtu\ai\3\svmhog\datasets\Train\pos'); 
neg_test = imageDatastore('D:\xjtu\ai\3\svmhog\datasets\Train\neg'); 
%% 显示训练的图片种类Labels和数量Count
Train_lable = countEachLabel(train);
disp(Train_lable);
%% 对训练集和测试集中的每张图像进行Hog特征提取
% % 预处理图像，得到feature特征大小，此大小与图像大小和Hog特征参数相关
imgSize = [256,256];% 对所有图像进行缩放
img1 = readimage(train, 1);
scaleImg = imresize(img1, imgSize);
[features, visualization] = extractHOGFeatures(scaleImg);
% imshow(scaleImg);
% hold on;
% plot(visualization)

% 对所有图像进行特征提取
numImg = length(train.Files);
featuresTrain = zeros(numImg,size(features,2),'single');%features train
for i = 1:numImg
    imgTrain = readimage(train,i);
    imgTrain = imresize(imgTrain, imgSize);
    featuresTrain(i,:) = extractHOGFeatures(imgTrain);
end

% 训练所有图像标签
trainLabels = train.Labels;

% 开始SVM多分类训练。二分类问题：fitcsvm；多分类问题：fitcecoc
classifier = fitcsvm(featuresTrain, trainLabels,'OptimizeHyperparameters','auto',...
    'HyperparameterOptimizationOptions',struct('AcquisitionFunctionName',...
    'expected-improvement-plus'));
save data.mat % 保存
% %% 预测并显示预测效果图
% for j = 1:10
% neg_numTest = length(neg_test.Files);
% pos_numTest = length(pos_test.Files);
% % 真实样本为负例
% FP = 0;%预测为正例
% TN = 0;%预测为负例
% %真实样本为正例
% TP = 0;%预测为正例
% FN = 0;%预测为负例
% for i = 1:neg_numTest
%     testImg = readimage(neg_test,i);
%     scaleTestImage = imresize(testImg,imgSize);
%     featureTest = extractHOGFeatures(scaleTestImage);
%     [predictIndex,score] = predict(classifier,featureTest);
% %     figure;
% %     imshow(testImg);
% %     title(['predictImage: ', char(predictIndex)]);
%      if(char(predictIndex)=="pos")
%          FP = FP + 1;
%      else
%          TN = TN + 1;
%      end
% end
% 
% for i = 1:pos_numTest
%     testImg = readimage(pos_test,i);
%     scaleTestImage = imresize(testImg,imgSize);
%     featureTest = extractHOGFeatures(scaleTestImage);
%     [predictIndex,score] = predict(classifier,featureTest);
% %     figure;
% %     imshow(testImg);
% %     title(['predictImage: ', char(predictIndex)]);
%      if(char(predictIndex)=="pos")
%          TP = TP + 1;
%      else
%          FN = FN + 1;
%      end
% end
% disp([TP,FN;FP,TN])
% end