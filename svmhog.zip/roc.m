clear;
clc;
load score.mat
ROC = [];
for thre = linspace(-3,3,6001)
    % neg
    FP = length(find(score_neg(:,1)>thre)); %真判定为假
    TN = length(score_neg(:,1))-FP; %假判定为假
    % pos
    TP = length(find(score_pos(:,2)>thre)); %真判定为真
    FN = length(score_pos(:,2))-TP; %假判定为真
    % 真正例率
    TPR = TP/(TP+FN);
    % 假正例率
    FPR =FP/(TN+FP);
    %     disp([TN,FP,TP,FN])
    % 查准率
    P = TP/(TP+FP);
    % 查全率
    R = TP/(TP+FN);
    %     ROC = [ROC;[R,P,thre]];
    ROC = [ROC;[TPR,FPR,thre]];
end
AUC = 1-sum(unique(ROC(:,2)))*(6/6000);
AUC = num2str(AUC);
AUC = ['AUC: ',AUC];
plot(ROC(:,1),ROC(:,2),'LineWidth',1.4)
title('Receiver Operating Characteristic Curve')
gtext(AUC)
xlabel('假正例率');
ylabel('真正例率');
axis([0 1 0 1]);