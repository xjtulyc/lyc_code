# -*- coding: utf-8 -*-
"""
Created on Tue Sep 28 19:39:11 2021
NLP Project 2: Text Clasifier
@author: Youcheng Li
"""
'''
朴素贝叶斯
'''
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import OneHotEncoder
from parameter import parameters as para
from preprocess import Preprocess as pre

class ProbabilisticsModels:
    def NaiveBayes_lyc(x_train,x_test,y_train,y_test):# 朴素贝叶斯，采用词袋法进行文本表示
        # 进行分词操作
        x_train_SplitWord = pre.SplitWord(x_train)
        x_train_SplitWord[:5]
        x_test_SplitWord = pre.SplitWord(x_test)
        x_test_SplitWord[:5]
        # 文本表示
        x_train_feature = pre.CountLexicon_XGB(para.StopWords,x_train_SplitWord)
        x_test_feature = pre.CountLexicon_XGB(para.StopWords,x_test_SplitWord)
        '''
        x_train = x_train.values
        x_test = x_test.values
        y_train = y_train.values
        y_test = y_test.values
        '''
        # array类型
        x_train_feature = np.array(x_train_feature.todense())
        x_test_feature = np.array(x_test_feature.todense())
        y_train = np.array(y_train)
        y_test = np.array(y_test)
        # interger encode
        label_encoder_train = LabelEncoder()
        integer_encoded_train = label_encoder_train.fit_transform(y_train)
        label_encoder_test = LabelEncoder()
        integer_encoded_test = label_encoder_test.fit_transform(y_test)
        # binary encode
        onehot_encoder_train = OneHotEncoder(sparse=False)
        integer_encoded_train = integer_encoded_train.reshape(len(integer_encoded_train), 1)
        onehot_encoded_train = onehot_encoder_train.fit_transform(integer_encoded_train)
        onehot_encoder_test = OneHotEncoder(sparse=False)
        integer_encoded_test = integer_encoded_test.reshape(len(integer_encoded_test), 1)
        onehot_encoded_test = onehot_encoder_test.fit_transform(integer_encoded_test)
        # Laplace Smoothing，由于文本特征比较稀疏，平滑对分布影响较大
        x_train_feature = np.add(x_train_feature,np.ones(x_train_feature.shape))/np.sum(x_train_feature)
        x_test_feature = np.add(x_test_feature,np.ones(x_test_feature.shape))/np.sum(x_test_feature)
        # 概率生成模型
        # 计算先验
        y = []
        for i in range(onehot_encoded_train.shape[1]):
            y.append(np.sum(onehot_encoded_train[:,i-1]))
        #y = y/np.sum(y)
        # 计算似然
        likely = np.zeros([onehot_encoded_train.shape[1],x_train_feature.shape[1]])
        for i in range(x_train_feature.shape[0]):
            index = np.argmax(onehot_encoded_train[i,:])
            for j in range(x_train_feature.shape[1]):
                likely[index,j-1] += x_train_feature[i-1,j-1]
        #模型验证
        score = [0,0]#[correct,wrong]
        for i in range(x_test_feature.shape[0]):#测试文本
            pred = np.zeros([onehot_encoded_train.shape[1]])
            for j in range(onehot_encoded_train.shape[1]):#预测类别
                pred[j-1] = y[j-1]
                for k in range(x_test_feature.shape[1]):#计算似然函数
                    #pred[j-1] = pred[j-1]*(likely[j-1,k-1]**x_test_feature[i-1,k-1])
                    pred[j-1] = pred[j-1]*(likely[j-1,k-1]**x_test_feature[i-1,k-1])
            if(np.argmax(pred)==np.argmax(onehot_encoded_test[i-1,:])): 
                score[0] = score[0] + 1
            else:
                score[1] = score[1] + 1
        score = score[1]/float(np.sum(score))
        return score