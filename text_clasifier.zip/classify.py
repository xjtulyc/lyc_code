# -*- coding: utf-8 -*-
"""
Created on Sun Sep 26 17:31:34 2021
NLP Project 2: Text Clasifier
@author: Youcheng Li
"""
'''
本文件包含文本分类方法：朴素贝叶斯，XGBoost，N-gram
'''
import numpy as np
import xgboost as xgb
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import OneHotEncoder
from parameter import parameters as para
from preprocess import Preprocess as pre
from sklearn.naive_bayes import MultinomialNB as nb
from ProbabilisticsModels import ProbabilisticsModels as pm

class classify:
    # 朴素贝叶斯（手写版本）
    def NaiveBayes_lyc(x_train,x_test,y_train,y_test):
        return pm.NaiveBayes_lyc(x_train,x_test,y_train,y_test)
    # 朴素贝叶斯（库函数版本）
    def NaiveBayes(article_feature,x_train,x_test,y_train,y_test):# 朴素贝叶斯
        classifier = nb()
        x_train_SplitWord = pre.SplitWord(x_train)
        x_train_SplitWord[:5]
        x_test_SplitWord = pre.SplitWord(x_test)
        x_test_SplitWord[:5]
        # 训练模型
        classifier.fit(article_feature.transform(x_train_SplitWord),y_train)
        # 预测
        score = classifier.score(article_feature.transform(x_test_SplitWord),y_test)
        return score
    
    # XGBoost
    def XGBoost(x_train,x_test,y_train,y_test):
        # 分词
        x_train_SplitWord = pre.SplitWord(x_train)
        x_train_SplitWord[:5]
        x_test_SplitWord = pre.SplitWord(x_test)
        x_test_SplitWord[:5]
        # 文本表示
        x_train_feature = pre.CountLexicon_XGB(para.StopWords,x_train_SplitWord)
        x_test_feature = pre.CountLexicon_XGB(para.StopWords,x_test_SplitWord)
        x_train = x_train.values
        x_test = x_test.values
        y_train = y_train.values
        y_test = y_test.values
        
        # 拟合XGBoost模型，需要array类型
        x_train_feature = np.array(x_train_feature.todense())
        x_test_feature = np.array(x_test_feature.todense())
        y_train = np.array(y_train)
        y_test = np.array(y_test)
        # interger encode
        label_encoder_train = LabelEncoder()
        integer_encoded_train = label_encoder_train.fit_transform(y_train)
        label_encoder_test = LabelEncoder()
        integer_encoded_test = label_encoder_test.fit_transform(y_test)
        # binary encode
        onehot_encoder_train = OneHotEncoder(sparse=False)
        integer_encoded_train = integer_encoded_train.reshape(len(integer_encoded_train), 1)
        onehot_encoded_train = onehot_encoder_train.fit_transform(integer_encoded_train)
        onehot_encoder_test = OneHotEncoder(sparse=False)
        integer_encoded_test = integer_encoded_test.reshape(len(integer_encoded_test), 1)
        onehot_encoded_test = onehot_encoder_test.fit_transform(integer_encoded_test)
        # XGBoost Classify
        classifier_test = []
        return x_test_feature
        for i in range(onehot_encoded_test.shape[1]):
            classifier_temp = xgb.DMatrix(x_test_feature,label=onehot_encoded_test[:,i-1])
            classifier_test.append(classifier_temp)
        classifier_train = []
        # 对于每个类型，逐个训练决策树
        for i in range(onehot_encoded_train.shape[1]):
            classifier_temp = xgb.DMatrix(x_train_feature,label=onehot_encoded_train[:,i-1])
            classifier_train.append(classifier_temp)
        param = para.xgb_param
        num_round = para.num_round
        models = []
        scores = []
        for i in range(onehot_encoded_train.shape[1]):
            trainlist = [(classifier_train[i],'train')]
            bst = xgb.train(param, classifier_train[i-1],num_boost_round=num_round,evals=trainlist)
            models.append(bst)
        # 对测试集进行预测
        for i in range(onehot_encoded_test.shape[1]):
            #preds = models[i-1].predict(classifier_test[i-1],ntree_limit=models[i-1].best_iteration)
            preds = models[i-1].predict(classifier_test[i-1])
            scores.append(np.mean(preds==onehot_encoded_test[:,i-1]))
        scores = np.max(scores)
        return scores
        
    # N-Gram
    def N_Gram(article_feature,x_train,x_test,y_train,y_test):
        classifier = nb()
        x_train_SplitWord = pre.SplitWord(x_train)
        x_train_SplitWord[:5]
        x_test_SplitWord = pre.SplitWord(x_test)
        x_test_SplitWord[:5]
        # 训练模型
        classifier.fit(article_feature.transform(x_train_SplitWord),y_train)
        # 预测
        score = classifier.score(article_feature.transform(x_test_SplitWord),y_test)
        return score
    