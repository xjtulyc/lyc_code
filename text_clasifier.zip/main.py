# -*- coding: utf-8 -*-
"""
Created on Fri Sep 24 08:41:10 2021
NLP Project 2: Text Clasifier
@author: Youcheng Li
"""
import time
import pandas as pd
from parameter import parameters as para
from preprocess import Preprocess as pre
from classify import classify

# def TextClasifier(repeat_times):
#     for i in range(repeat_times):
#         # 预处理
#         '''
#         对文本数据进行预处理：
#         1. 读入分类好的csv文件；
#         '''
#         #读入csv文件，并分为数据集和测试集
#         x_train, x_test, y_train, y_test = pre.getRawData(para.csv_Sohu_Full)
        
#         #中文分词
#         x_train_SplitWord = pre.SplitWord(x_train)
        
#         '''
#         # 文本表示
#         1. 获得屏蔽词StopWords.txt；
#         2. 提取文本特征：词袋，TF-IDF
#         '''
        
#         #词袋表示法
#         CountV = pre.CountLexicon(para.StopWords,x_train_SplitWord)
        
#         #TF-IDF
#         TF_V = pre.TF_IDF_Lexicon(para.StopWords,x_train_SplitWord)
#         #TF-IDF for N-Gram
#         TF_V_N = pre.TF_IDF_Lexicon_N_Gram(para.StopWords,x_train_SplitWord,1)
        
#         # 分类模型
#         '''
#         1. Probabilistics Models:朴素贝叶斯，N-Gram
#         2. Decision Models:XGBoost
#         3. Instance-based Methods:KNN
#         '''
        
#         t_begin = time.time()
#         print()
#         NaiveBayes_lyc = classify.NaiveBayes_lyc(x_train, x_test, y_train, y_test)
#         print('Naive Bayes written by myself(count vector) rate:',NaiveBayes_lyc)
        
#         # Naive Bayes
#         NB_score_V = classify.NaiveBayes(CountV,x_train, x_test, y_train, y_test)
#         print('Naive Bayes(count vector) rate:',NB_score_V)
        
#         NB_score_TF = classify.NaiveBayes(TF_V,x_train, x_test, y_train, y_test)
#         print('Naive Bayes(TF-IDF vector) rate:',NB_score_TF)
#         # N-Gram
#         N_score = classify.N_Gram(TF_V_N,x_train, x_test, y_train, y_test)
#         print('N-Gram(TF-IDF vector) rate:',N_score)
        
#         # XGBoost
        
#         XGB_score = classify.XGBoost(x_train, x_test, y_train, y_test)
#         print('XGBoost(TF-IDF vector) rate:',XGB_score)
        
        
#         # 评价
#         '''
#         各种分类模型的分类结果进行评价
#         '''
#         t_stop = time.time()
#         print('run time',-t_begin+t_stop)
        
#         # 存储数据
#         df = pd.DataFrame()
#         df = df.append([{'run time':-t_begin+t_stop,
#                          'Naive Bayes written by myself(count vector)':NaiveBayes_lyc,
#                          'Naive Bayes(Count Vector)':NB_score_V,
#                          'Naive Bayes(TF-IDF Vector)':NB_score_TF,
#                          'N-Gram(TF-IDF Vector)':N_score,
#                          'XGBoost(TF-IDF vector) rate':XGB_score}],
#                        ignore_index=True)
#         df.to_csv(para.result,line_terminator="\n",index=False,index_label=None,header=False,mode='a+',encoding='utf-8')
        
# TextClasifier(1)

# for i in range(repeat_times):
# 预处理
'''
对文本数据进行预处理：
1. 读入分类好的csv文件；
'''
#读入csv文件，并分为数据集和测试集
x_train, x_test, y_train, y_test = pre.getRawData(para.csv_Sohu_Full)

#中文分词
x_train_SplitWord = pre.SplitWord(x_train)

'''
# 文本表示
1. 获得屏蔽词StopWords.txt；
2. 提取文本特征：词袋，TF-IDF
'''

#词袋表示法
CountV = pre.CountLexicon(para.StopWords,x_train_SplitWord)

#TF-IDF
TF_V = pre.TF_IDF_Lexicon(para.StopWords,x_train_SplitWord)
#TF-IDF for N-Gram
TF_V_N = pre.TF_IDF_Lexicon_N_Gram(para.StopWords,x_train_SplitWord,1)

# 分类模型
'''
1. Probabilistics Models:朴素贝叶斯，N-Gram
2. Decision Models:XGBoost
3. Instance-based Methods:KNN
'''

t_begin = time.time()
print()
NaiveBayes_lyc = classify.NaiveBayes_lyc(x_train, x_test, y_train, y_test)
print('Naive Bayes written by myself(count vector) rate:',NaiveBayes_lyc)

# Naive Bayes
NB_score_V = classify.NaiveBayes(CountV,x_train, x_test, y_train, y_test)
print('Naive Bayes(count vector) rate:',NB_score_V)

NB_score_TF = classify.NaiveBayes(TF_V,x_train, x_test, y_train, y_test)
print('Naive Bayes(TF-IDF vector) rate:',NB_score_TF)
# N-Gram
N_score = classify.N_Gram(TF_V_N,x_train, x_test, y_train, y_test)
print('N-Gram(TF-IDF vector) rate:',N_score)

# XGBoost

XGB_score = classify.XGBoost(x_train, x_test, y_train, y_test)
print('XGBoost(TF-IDF vector) rate:',XGB_score)


# 评价
'''
各种分类模型的分类结果进行评价
'''
t_stop = time.time()
print('run time',-t_begin+t_stop)

# 存储数据
df = pd.DataFrame()
df = df.append([{'run time':-t_begin+t_stop,
                  'Naive Bayes written by myself(count vector)':NaiveBayes_lyc,
                  'Naive Bayes(Count Vector)':NB_score_V,
                  'Naive Bayes(TF-IDF Vector)':NB_score_TF,
                  'N-Gram(TF-IDF Vector)':N_score,
                  'XGBoost(TF-IDF vector) rate':XGB_score}],
                ignore_index=True)
df.to_csv(para.result,line_terminator="\n",index=False,index_label=None,header=False,mode='a+',encoding='utf-8')
