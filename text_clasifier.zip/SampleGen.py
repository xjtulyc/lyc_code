# -*- coding: utf-8 -*-
"""
Created on Sat Sep 25 20:36:07 2021

@author: 12463
"""
'''
当'sample'文件夹为空时，请运行本脚本
大批量数据处理时，推荐使用UltraEdit打开csv文件
将搜狗语料库新闻语料转化为dataframe格式，便于后续文本分类处理
'''
import os
import re
import pandas as pd
from parameter import parameters as para

'''生成原始语料文件夹下文件列表'''
def listdir(path, list_name):
    for file in os.listdir(path):
        file_path = os.path.join(path, file)
        if os.path.isdir(file_path):
                listdir(file_path, list_name)
        else:
                list_name.append(file_path)

'''字符数小于这个数目的content将不被保存'''
threh = 30
'''获取所有语料'''
list_name = []
listdir(para.Sohu_Small,list_name)

print('当\'sample\'文件夹为空时，请运行本脚本\n大批量数据处理时，推荐使用UltraEdit打开csv文件')
'''对每个语料'''
#for path in list_name:
for path in [list_name[0]]:
    print(path)
    file = open(path, 'rb').read().decode("utf8")

    '''
    正则匹配出url和content
    '''
    patternURL = re.compile(r'<url>(.*?)</url>', re.S)
    patternCtt = re.compile(r'<content>(.*?)</content>', re.S)

    classes = patternURL.findall(file)
    contents = patternCtt.findall(file)

    '''
    # 把所有内容小于30字符的文本全部过滤掉
    '''
    for i in range(contents.__len__())[::-1]:
        if len(contents[i]) < threh:
            contents.pop(i)
            classes.pop(i)

    '''
    把url进一步提取出来，只提取出一级url作为类别
    '''
    for i in range(classes.__len__()):
        patternClass = re.compile(r'http://(.*?).sohu.com/',re.S)
        classi = patternClass.findall(classes[i])
        classes[i] = classi[0]
    print('共有',classes.__len__(),'个文本')
    '''
    按照url作为类别保存到samples文件夹中
    '''
    '''
    for i in range(classes.__len__()):
        file = 'data_SohuNews_Small/samples/' + classes[i] + '.txt'
        f = open(file,'a+',encoding='utf-8')
        f.write(contents[i]+'\n')   #加\n换行显示
    '''
    
    '''
    按照'类别-内容'存储为dataframe，并保存为csv文件
    '''
    '''
    分页处理，提高运算效率
    '''
    '''
    page_size = 1
    for i in range(int(len(classes)/page_size)):
        df = pd.DataFrame()
        for j in range(page_size):
            df = df.append([{'class':classes[i*page_size+j],'content':contents[i*page_size+j]}],ignore_index=True)
            #df.loc[j] = [{:classes[page_size*i+j],1:contents[page_size*i+j]}]
        # 打开目标csc文件
        df.to_csv(para.csv_Sohu_Full,line_terminator="\n",index=False,index_label=None,header=False,mode='a+',encoding='utf-8')
    '''
    df = pd.DataFrame(columns=('class','content'))
    for i in range(len(classes)):
        df = df.append([{'class':classes[i],'content':contents[i]}],ignore_index=True)
    df.to_csv(para.csv_Sohu_Small,mode='a+',encoding='utf-8')