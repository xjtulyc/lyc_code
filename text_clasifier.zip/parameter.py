# -*- coding: utf-8 -*-
"""
Created on Sun Sep 26 17:51:44 2021
NLP Project 2: Text Clasifier
@author: Youcheng Li
"""
'''
本文件包含文本分类任务中必要的参数
'''
class parameters:
    # data set
    Sohu_Full = 'data_SohuNews_Full/'
    Sohu_Small = 'data_SohuNews_Small/'
    RMRB = ''
    
    # csv dir
    csv_Sohu_Full = 'data_SohuNews_Full/samples/data_Sohu_Full.csv'
    csv_Sohu_Small = 'data_SohuNews_Small/samples/data_Sohu_Small.csv'

    # stop words
    StopWords = 'stopwords/StopWords.txt'
    
    # classify result
    result = 'result/result.csv'
    
    # XGBoost Parameters
    xgb_param = {
    'booster': 'gbtree',  # 使用gbtree
    'objective': 'multi:softmax',  # 多分类的问题、
    # 'objective': 'multi:softprob',   # 多分类概率
     #'objective': 'binary:logistic',  #二分类
    'eval_metric': 'mlogloss',  # logloss
    'num_class': 4,  # 类别数，与 multisoftmax 并用
    'gamma': 0.1,  # 用于控制是否后剪枝的参数,越大越保守，一般0.1、0.2这样子。
    'max_depth': 8,  # 构建树的深度，越大越容易过拟合
    'alpha': 0,  # L1正则化系数
    'lambda': 10,  # 控制模型复杂度的权重值的L2正则化项参数，参数越大，模型越不容易过拟合。
    'subsample': 0.7,  # 随机采样训练样本
    'colsample_bytree': 0.5,  # 生成树时进行的列采样
    'min_child_weight': 3,
    # 这个参数默认是 1，是每个叶子里面 h 的和至少是多少，对正负样本不均衡时的 0-1 分类而言
    # 假设 h 在 0.01 附近，min_child_weight 为 1 意味着叶子节点中最少需要包含 100 个样本。
    # 这个参数非常影响结果，控制叶子节点中二阶导的和的最小值，该参数值越小，越容易 overfitting。
    'silent': 0,  # 设置成1则没有运行信息输出，最好是设置为0.
    'eta': 0.03,  # 如同学习率
    'seed': 1000,
    'nthread': -1,  # cpu 线程数
    'missing': 1
    # 'scale_pos_weight': (np.sum(y==0)/np.sum(y==1))  # 用来处理正负样本不均衡的问题,通常取：sum(negative cases) / sum(positive cases)
    }

    num_round = 10000#循环次数