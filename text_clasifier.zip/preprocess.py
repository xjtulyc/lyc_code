# -*- coding: utf-8 -*-
"""
Created on Sun Sep 26 17:19:17 2021
NLP Project 2: Text Clasifier
@author: Youcheng Li
"""
'''
本文件包含文本分类预处理方法：读入数据；中文分词；文本表示方法：词库表示法；
'''
import jieba as jb
import pandas as pd
import csv
from sklearn.feature_extraction.text import TfidfVectorizer as TF_IDF
from sklearn.feature_extraction.text import CountVectorizer as Count
from sklearn.model_selection import train_test_split

class Preprocess:
    # 读入数据+划分数据集
    '''
    数据集：
        1. para.csv_Sohu_Small
        2. para.csv_Sohu_Full
    数据集大小：
        在使用para.csv_Sohu_Full数据集的时候，为了提高运算效率，可以考虑提取部分数据
        Data_Set_Size的单位为'万'
    '''
    def getRawData(Data_Set_Name):
        data = pd.read_csv(Data_Set_Name,header=0)
        data.dropna(inplace=True)
        x_train, x_test, y_train, y_test = train_test_split(data['content'], data['class'],random_state=None)
        return x_train, x_test, y_train, y_test
    
    def getRawDataXGB(Data_Set_Name):
        with open(Data_Set_Name, 'rb') as csvfile:
            reader = csv.reader(csvfile)
            column1 = [row for row in reader]
        content_train = [i[1] for i in column1] # 第一列为文本内容，并去除列名
        opinion_train = [int(i[0])-1 for i in column1] # 第二列为类别，并去除列名
        train = [content_train, opinion_train]
        return train

    # 中文分词
    '''
    将提取的数据集进行分词：
        1. 分词工具为jieba('https://pypi.org/project/jieba/')
    '''
    def SplitWord(train_data):
        return train_data.apply(lambda x:' '.join(jb.cut(x)))
    
    # 文本表示
    '''
    文本特征向量(VSM)表示：
        1. 停用词：根据所有文本中出现频率最高的词汇(DF)选择
        2. 词袋法表示文本特征
        2. TF-IDF法表示文本特征
    '''
    # 词袋法
    def CountLexicon(stopwords,train_SplitWord):#train_SplitWord是分词后的原文档
        infile = open(stopwords,encoding='utf-8')
        stopwords_lst = infile.readlines()
        stopwords = [x.strip() for x in stopwords_lst]
        article_feature = Count(stop_words=stopwords,max_features=5000)
        #article_feature.todense()#稠密表示
        article_feature = article_feature.fit(train_SplitWord)
        return article_feature
    # TF-IDF法
    def TF_IDF_Lexicon(stopwords,train_SplitWord):
        infile = open(stopwords,encoding='utf-8')
        stopwords_lst = infile.readlines()
        stopwords = [x.strip() for x in stopwords_lst]
        article_feature = TF_IDF(stop_words=stopwords, max_features=5000, lowercase = False)
        #article_feature.todense()#稠密表示
        article_feature.fit(train_SplitWord)
        return article_feature
    
    def TF_IDF_Lexicon_N_Gram(stopwords,train_SplitWord,N=1):
        infile = open(stopwords,encoding='utf-8')
        stopwords_lst = infile.readlines()
        stopwords = [x.strip() for x in stopwords_lst]
        article_feature = TF_IDF(stop_words=stopwords, max_features=5000,ngram_range=(1,N), lowercase = False)
        #article_feature.todense()#稠密表示
        article_feature.fit(train_SplitWord)
        return article_feature
    
    def CountLexicon_XGB(stopwords,train_SplitWord):#train_SplitWord是分词后的原文档
        infile = open(stopwords,encoding='utf-8')
        stopwords_lst = infile.readlines()
        stopwords = [x.strip() for x in stopwords_lst]
        article_feature = Count(stop_words=stopwords,max_features=5000)
        #article_feature.todense()#稠密表示
        article_feature = article_feature.fit_transform(train_SplitWord)
        return article_feature