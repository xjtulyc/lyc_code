# -*- coding: utf-8 -*-
"""
Created on Sat Oct  2 22:18:07 2021
NLP Project3: Backward Maximum Matching
@author: Youcheng Li
"""
import jieba as jb
class dic_develop(object):
    def __init__(self):
        self.__rawdata = 'rawdata.txt'
        self.dictionary = set()
        self.maximum = 0
        
    def develop(self):
        with open(self.__rawdata, 'r+', encoding='utf-8') as f:
            string = f.read()
            seg = jb.lcut(string,cut_all=True,HMM=False)
        return seg
if __name__ == '__main__':
    d = dic_develop()
    '''
    with open('rawdata.txt', 'r', encoding='utf-8') as f:
            string = f.read()
            print(string)
    '''
    dic = d.develop()
    with open('dic.txt','w+',encoding='utf-8') as f:
        dic = '\n'.join(dic)
        f.write(dic)
    print("Finished...")