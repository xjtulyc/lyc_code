# -*- coding: utf-8 -*-
"""
Created on Tue Oct  5 18:27:39 2021
NLP Project3: Forward Maximum Matching
@author: Youcheng Li
"""
import jieba as jb
class FMM(object):
    def __init__(self, dict_path):
        self.dictionary = set()
        self.maximum = 0
        with open(dict_path, 'r+', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                self.dictionary.add(line)
                if len(line) > self.maximum:
                    self.maximum = len(line)
    def cut(self,text):
        result = []
        index = 0
        while index<len(text):
            for size in range(index+self.maximum,index,-1):
                piece = text[index:size]
                if piece in self.dictionary:
                    index = size
                    break
                if(size==index+1):
                    index = size
            result.append(piece)
        return result
    
if __name__ == '__main__':
    print('测试1:')
    text = '研究生命的起源'
    print('测试1所用文本:',text)
    tokenizer = FMM('dic.txt')
    print('测试1分词结果:',tokenizer.cut(text))
    print()
    print('测试2:')
    with open('rawdata.txt','r',encoding='utf-8') as f:
        text = f.read()
        print('测试2所用文本:',text)
        seg1 = tokenizer.cut(text)
        print('测试2分词结果:',tokenizer.cut(text))
        print('FMM算法与jieba方法比较:')
        seg2 = jb.lcut(text,cut_all=False,HMM=False)
        print('jieba分词数目',len(seg2),'FMM分词数目',len(seg1))