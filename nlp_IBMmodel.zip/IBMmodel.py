# -*- coding: utf-8 -*-
"""
Created on Sat Oct 23 01:31:25 2021
IBM model
@author: Li Youcheng
"""
import csv
import os
import numpy as np
import time

class IBM:
    def __init__(self):
        # corpus_path = 'corpus\\'
        corpus_path = 'corpus/'
        corpus_list = os.listdir(corpus_path)
        if corpus_list:
            self.en = np.load(corpus_path+'en_data.npy')
            self.zh = np.load(corpus_path+'zh_data.npy')
            self.corpus_num = len(self.zh)#语料库长度，用k索引
        else:
            pass
        
        #加载已有参数，如果没有，进行随机初始化
        # middle_data_path = 'middle_data\\'
        middle_data_path = 'middle_data/'
        save_name = 'middle_data.npz'
        middle_data_list = os.listdir(middle_data_path)
        if middle_data_list:
            data = np.load(middle_data_path+save_name, allow_pickle=True)
            self.c_j_ilm = data['c_j_ilm']#c(j|i,l,m) 
            self.c_ilm = data['c_ilm']#c(i,l,m) all
            self.c_ejl_fim = data['c_ejl_fim']
            self.c_ej = data['c_ej']
            self.t_f_e = data['t_f_e']
            self.q_j_ilm = data['q_j_ilm']
        #各种初始化
        else:
            pass
    
    def IBM1(self):
        ibm1_align = []
        for k in range(self.corpus_num):
            l = len(self.zh[k])-1#中文语料长度
            m = len(self.en[k])-1#英文语料长度
            #贪婪算法求最佳匹配
            align = []
            if l<1 or m<1:
                ibm1_align.append([0]*(m+1))
                continue
            for i in range(m):
                align.append(np.argmax(self.t_f_e[i,:l,k]))
            ibm1_align.append(align)
        return ibm1_align
    
    def IBM2(self):
        ibm2_align = []
        for k in range(self.corpus_num):
            l = len(self.zh[k])-1#中文语料长度
            m = len(self.en[k])-1#英文语料长度
            #贪婪算法求最佳匹配
            align = []
            if l<1 or m<1:
                ibm2_align.append([0]*(m+1))
                continue
            #对应位置相乘，求贪婪
            q = self.q_j_ilm[:l,:m,l,m].T*self.t_f_e[:m,:l,k]
            for i in range(m):
                align.append(np.argmax(q[i,:l]))
            ibm2_align.append(align)
        return ibm2_align

if __name__ == '__main__':
    start_time = time.time()
    ibm_model = IBM()
    ibm1_align = ibm_model.IBM1()
    ibm2_align = ibm_model.IBM2()
    
    #将结果写入csv中
    headers = ['zh','en','IBM1 align','IBM2 align']
    f = open('text_alignment.csv','w')
    writer = csv.writer(f)
    writer.writerow(headers)
    for i in range(ibm_model.corpus_num):
        row = [ibm_model.zh[i],
               ibm_model.en[i],
               ibm1_align[i],
               ibm2_align[i]]
        writer.writerow(row)
    f.close()
    print('Run time {:.4f}s'.format(time.time()-start_time))