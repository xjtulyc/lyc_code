# -*- coding: utf-8 -*-
"""
Created on Sat Oct 23 01:43:12 2021
IBM corpus generation
@author: Li Youcheng
"""
# 导入第三方库
# import pandas as pd
import os
import numpy as np
import time
# from math import exp as e
# 创建容器
run_start = time.time()
data = {}
en_data = []
zh_data = []
# 导入平行预料
corpus_path = 'corpus\\'
# corpus_path = 'corpus/'
corpus_list = os.listdir(corpus_path)
if corpus_list:
    np.load(corpus_path+'en_data.npy')
    np.load(corpus_path+'zh_data.npy')
else:
    with open('datasets\\en.txt','r') as en:
    # with open('datasets/en.txt','r') as en:
        for line in en.readlines():
            line = line.strip('\n')
            index = 0
            list_line = []
            for i in range(len(line)):
                if(line[i]==' '):
                    list_line.append(line[index:i])
                    index = i + 1
            en_data.append(list_line)
        en_data = en_data[0:2000]
    with open('datasets\\cn.txt','r', encoding='utf-8') as zh:
    # with open('datasets/cn.txt','r', encoding='utf-8') as zh:
        for line in zh.readlines():
            line = line.strip('\n')
            index = 0
            list_line = []
            for i in range(len(line)):
                if(line[i]==' '):
                    list_line.append(line[index:i])
                    index = i + 1
            zh_data.append(list_line)
        zh_data = zh_data[0:2000]
    np.save(corpus_path+'en_data',en_data)
    np.save(corpus_path+'zh_data',zh_data)

#使用EM算法进行词对齐Alignment
EPOCHS = 20#迭代轮数
m_max = 0#英文文本最大长度
l_max = 0#中文文本最大长度
parallel_corpus = [zh_data, en_data]#平行语料库
for k in range(len(parallel_corpus[0])):#获取中英文文本最大长度
    m_max = max(m_max, len(parallel_corpus[1][k]))# eng 58
    l_max = max(l_max, len(parallel_corpus[0][k]))# cn 67
    
#加载已有参数，如果没有，进行随机初始化
middle_data_path = 'middle_data\\'
# middle_data_path = 'middle_data/'
save_name = 'middle_data.npz'
middle_data_list = os.listdir(middle_data_path)
if middle_data_list:
    data = np.load(middle_data_path+save_name, allow_pickle=True)
    c_j_ilm = data['c_j_ilm']#c(j|i,l,m) 
    c_ilm = data['c_ilm']#c(i,l,m) all
    c_ejl_fim = data['c_ejl_fim']
    c_ej = data['c_ej']
    t_f_e = data['t_f_e']
    q_j_ilm = data['q_j_ilm']
#各种初始化
else:
    c_j_ilm = np.random.rand(l_max,m_max,l_max,m_max)#c(j|i,l,m) 
    c_ilm = np.random.rand(m_max,l_max,m_max)#c(i,l,m) all
    c_ejl_fim = np.random.rand(l_max,m_max,len(parallel_corpus[0]))
    c_ej = np.random.rand(l_max,len(parallel_corpus[0]))
    t_f_e = np.random.rand(m_max,l_max,len(parallel_corpus[0]))
    q_j_ilm = np.random.rand(l_max,m_max,l_max,m_max)


d_kij = np.zeros((len(parallel_corpus[0]),m_max,l_max))
for epoch in range(EPOCHS):
    time_start = time.time()#记录每一轮时间
    #start
    
    for k in range(len(parallel_corpus[0])):# 总语料数目
        
        #f为英文 e为中文
        m = len(parallel_corpus[1][k])-1#第k个英文语料长度
        l = len(parallel_corpus[0][k])-1#第k个中文预料长度
        for i in range(m):#遍历英文语料每一个单词 m
            for j in range(l):#遍历中文语料每一个单词 l
                t_f_e[i][j][k] = c_ejl_fim[j][i][k]/c_ej[j][k]
                q_j_ilm[j][i][l][m] = c_j_ilm[j][i][l][m]/c_ilm[i][l][m]
        for i in range(m):#遍历英文语料每一个单词 m
            for j in range(l):#遍历中文语料每一个单词 l
                d_kij[k][i][j] = q_j_ilm[j][i][l][m]*t_f_e[i][j][k]
        # d_kij = d_kij/np.amax(d_kij)
        for i in range(m):#遍历英文语料每一个单词 m
            for j in range(l):#遍历中文语料每一个单词 l
                c_ejl_fim[j][i][k] = c_ejl_fim[j][i][k] + d_kij[k][i][j]
                c_ej[j][k] = c_ej[j][k] + d_kij[k][i][j]
                c_j_ilm[j][i][l][m] = c_j_ilm[j][i][l][m] + d_kij[k][i][j]
                c_ilm[i][l][m] = c_ilm[i][l][m] + d_kij[k][i][j]
    # end
    # print(t_f_e,q_j_ilm)
    print('Epoch {} time {:.4f}s'.format(epoch + 1, time.time() - time_start))

# 保存中间变量
np.savez(middle_data_path+save_name,c_j_ilm=c_j_ilm,
         c_ilm=c_ilm,
         c_ejl_fim=c_ejl_fim,
         c_ej=c_ej,
         t_f_e=t_f_e,
         q_j_ilm=q_j_ilm)

# # 创建Dataframe

# data['zh'] = zh_data
# data['en'] = en_data

print('Stop running...\ntime {:.4f}s'.format(time.time()-run_start))